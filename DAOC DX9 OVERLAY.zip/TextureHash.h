#pragma once

#include <cstdint>
#include <cstddef>

uint32_t HashTextureMemory(const void* data, size_t size);
